## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(lyric.analysis)

## ---- include = FALSE---------------------------------------------------------
#loading all required packages
install.packages("xml2", repos = "http://cran.us.r-project.org")
install.packages("rvest", repos = "http://cran.us.r-project.org")
install.packages("textclean", repos = "http://cran.us.r-project.org")
install.packages("syuzhet", repos = "http://cran.us.r-project.org")
install.packages("wordcloud", repos = "http://cran.us.r-project.org") #makes the wordcloud
install.packages("RColorBrewer", repos = "http://cran.us.r-project.org") #color selection, not totally necessary but nice
install.packages("tm", repos = "http://cran.us.r-project.org") #document term matrix
install.packages("stringr", repos = "http://cran.us.r-project.org") #document term matrix
library(rvest)
library(xml2)
library(stringr)
library(textclean)
library(syuzhet)
library(wordcloud)
library(RColorBrewer)
library(tm)

## ---- include=TRUE------------------------------------------------------------
getArtist <- function(artist){
  artist <- tolower(gsub(" ","-", gsub("[().]","", gsub("'","-",artist))))
  url <- paste('https://www.songlyrics.com/',artist,'-lyrics/', sep='')
  
  singer <- url %>% 
    httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>% 
    read_html() 
  
  track_links <<- singer %>%
    html_nodes('table') %>% html_nodes('tr') %>% html_node('a') %>%
    html_attr('href')
  
  track_links <<- track_links[1:(length(track_links) - 2)]
  
  lyricVector <- c()
  songNameVector <- c()
  
  for(num in 1:length(track_links)){
    track_url <- track_links[num]
    song <- track_url %>%
      httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>% 
      read_html()  
    songName <- song %>% html_elements('title') %>% html_text2()
    lyrics <- song %>% html_elements('#songLyricsDiv') %>% html_text2()
    songNameVector[num] <- songName
    lyricVector[num] <- lyrics
  }
  lyrics <- cbind(lyricVector, songNameVector)
  lyrics 
}
allSongs <- getArtist('Billie Eilish')

getSong <- function(name, artist){
  name <- tolower(gsub(" ","-", gsub("[().']","", gsub("'","-",name))))
  artist <- gsub(" ", "-", artist)
  url <- paste("https://www.songlyrics.com/",artist, "/", name, "-lyrics/", sep='')
  track_url <-url
  song <- track_url %>%
    httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>%
    read_html()
  songName <- song %>% html_elements("title") %>% html_text2()
  songlyrics <- song %>% html_elements('#songLyricsDiv') %>% html_text2()
  lyrics <- cbind(songlyrics, songName)
  lyrics
}
bellyAche <- getSong('Billie Eilish','bellyache')

## ---- include=FALSE-----------------------------------------------------------
getArtist <- function(artist){
  artist <- tolower(gsub(" ","-", gsub("[().]","", gsub("'","-",artist))))
  
  url <- paste('https://www.songlyrics.com/',artist,'-lyrics/', sep='')
  singer <- url %>% 
    httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>% 
    read_html() 
  
  track_links <<- singer %>%
    html_nodes('table') %>% html_nodes('tr') %>% html_node('a') %>%
    html_attr('href')
  
  track_links <<- track_links[1:(length(track_links) - 2)]
  
  lyricVector <- c()
  songNameVector <- c()
  for(num in 1:length(track_links)){
    
    track_url <- track_links[num]
    song <- track_url %>%
      httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>% 
      read_html()  
    songName <- song %>% html_elements('title') %>% html_text2()
    lyrics <- song %>% html_elements('#songLyricsDiv') %>% html_text2()
    songNameVector[num] <- songName
    lyricVector[num] <- lyrics
  }
  lyrics <- cbind(lyricVector, songNameVector)
  lyrics 
}
allSongs <- getArtist('Billie Eilish')

## ---- format lyrics function--------------------------------------------------
formatLyrics <- function(lyrics){
  list_mat <- list()
  for(num in 1:length(lyrics[,1])){
    a <- strsplit(lyrics[num,1], split = '\n')
    a <- unlist(a)
    
    z <- rep(lyrics[num,2], length(a))
    
    f <- cbind(a,z)
    
    list_mat[[num]] <- f
    
  }
  list_mat <- do.call(rbind, list_mat)
  list_mat <- data.frame(list_mat)
  
  list_mat[c('artist','song title')] <- str_split_fixed(list_mat$z, ' - ', 2)
  list_mat <- list_mat[c('a', 'artist', 'song title')]
  
  row.names(list_mat) <- NULL
  
  colnames(list_mat) <- c('lyrics', 'artist', 'song title')
  
  list_mat[,'lyrics'] <- sub('\r', "", list_mat[,'lyrics'])
  list_mat
}


## ---- format lyrics example---------------------------------------------------
allLyrics <- formatLyrics(allSongs)
head(allLyrics, 10)

## ---- clean lyrics function---------------------------------------------------
cleanLyrics <- function(lyr, expContractions = FALSE){
  
  lyr <- lyr[!(lyr$lyrics == ""), ] #get rid of empty lyric rows
  rownames(lyr) <- 1:nrow(lyr) # renumber index 
  
  for(row in 1:length(lyr[,1])){ # converts digits to words
    lyr[row,1] <- replace_number(lyr[row,1])
  }
  
  if(expContractions == TRUE){ 
    for(row in 1:length(lyr[,1])){ # expands contractions
      lyr[row,1] <- replace_contraction(lyr[row,1])
    }
  }
  
  for(row in 1:length(lyr[,1])){
    lyr[row,1] <- str_replace_all(lyr[row,1], "[[:punct:]]", "")
  }
  
  lyr
}

## ---- clean lyrics example----------------------------------------------------
allLyrics <- cleanLyrics(allLyrics, expContractions = TRUE)
head(allLyrics, 10)

## ---- include = FALSE---------------------------------------------------------
#get_dtm()
get_dtm <- function(cleanedlyrics){
  #making a document term matrix from the dataframe of cleaned lyrics 
  dtm <- TermDocumentMatrix(cleanedlyrics[,1]) 
  matrix <- as.matrix(dtm) 
  words <- sort(rowSums(matrix),decreasing=TRUE) 
  df <- data.frame(word = names(words),freq=words)
}

#sentimentProportion()
sentimentProportion <- function(x){
  sentimentMatrix <- get_nrc_sentiment(x)
  proportions <- colSums(sentimentMatrix) / length(x)
  proportions
}

#get_wordcloud()
get_wordcloud <- function(cleanedlyrics = NULL, dtm = FALSE) {
  if (dtm == TRUE) {
    wc <- wordcloud(words = cleanedlyrics$word, freq = cleanedlyrics$freq, min.freq = 2, max.words = 200,
                    random.order = FALSE, rot.per = 0.25, colors = brewer.pal(8, "Accent") )
    return(invisible(wc))
  }
  
  #making a document term matrix from the dataframe of cleaned lyrics
  dtm <- TermDocumentMatrix(cleanedlyrics[, 1])
  matrix <- as.matrix(dtm)
  words <- sort(rowSums(matrix), decreasing = TRUE)
  df <- data.frame(word = names(words), freq = words)
  
  #making the actual wordcloud using the wordcloud package
  wc <- wordcloud(words = df$word, freq = df$freq, min.freq = 2, max.words = 200,
            random.order = FALSE, rot.per = 0.25, colors = brewer.pal(8, "Accent") )
  return(invisible(wc))
}

#top5words()
top5words <- function(data, dtm = FALSE) {
  #dtm or cleaned lyrics as input?
  if (dtm == TRUE) {
    #if input is already a DTM, do this
    bp <- barplot(data$freq[1:5], names.arg = data$word[1:5], col = "peachpuff4")
    return(invisible(bp))
  }
  
  #otherwise, we need to make a dtm first
  dtm <- TermDocumentMatrix(data[, 1])
  matrix <- as.matrix(dtm)
  words <- sort(rowSums(matrix), decreasing = TRUE)
  df <- data.frame(word = names(words), freq = words)
  
  bp <- barplot(df$freq[1:5], names.arg = df$word[1:5], col = "peachpuff4")
  return(invisible(bp))
}


## ---- get_dtm() example-------------------------------------------------------
#allLyrics, the data frame of formatted and cleaned lyrics from the previous section
lyrics_dtm <- get_dtm(allLyrics)
head(lyrics_dtm,10)

## ---- warning=FALSE-----------------------------------------------------------
sentimentProportion(allLyrics[,1])

## ---- warning = F-------------------------------------------------------------
#using a data frame
get_wordcloud(allLyrics)

## ---- warning = F-------------------------------------------------------------
#using a DTM
get_wordcloud(lyrics_dtm, dtm = TRUE)

## ---- fig.width = 5, fig.height=5---------------------------------------------
#using a data frame
top5words(allLyrics)

## ---- fig.width = 5, fig.height=5---------------------------------------------
#using a DTM
top5words(lyrics_dtm, dtm = TRUE)

