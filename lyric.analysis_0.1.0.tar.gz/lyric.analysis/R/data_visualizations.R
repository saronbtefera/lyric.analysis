#' creates a wordcloud from lyrics
#'
#' Creates a wordcloud from a Document Term Matrix or data frame of formatted and cleaned lyrics
#'
#' @importFrom wordcloud wordcloud
#' @importFrom tm TermDocumentMatrix
#' @importFrom RColorBrewer brewer.pal
#'
#' @param cleanedlyrics data frame of formatted and cleaned lyrics by formatLyrics() and cleanLyrics() or a Document Term Matrix of lyrics
#' @param dtm boolean that indicates if cleanedlyrics is a data frame or Document Term Matrix
#'
#' @return plot, word cloud of lyrics
#' @export
#'
#' @examples
#' billieLyrics <- getArtist('Billie Eilish')
#' formatted_lyrics <- formatLyrics(billieLyrics)
#' cleaned_lyrics <- cleanLyrics(formatted_lyrics, exp_contractions = TRUE)
#' my_dtm <- get_dtm(cleaned_lyrics)
#' get_wordcloud(cleaned_lyrics, dtm = F)
#' get_wordcloud(my_dtm, dtm = T)
get_wordcloud <- function(cleanedlyrics = NULL, dtm = FALSE) {
  if (dtm == TRUE) {
    wc <- wordcloud(words = cleanedlyrics$word, freq = cleanedlyrics$freq, min.freq = 1, max.words = 500,
                    random.order = FALSE, rot.per = 0.35, colors = brewer.pal(8, "Dark2") )
    return(invisible(wc))
  }

  #making a document term matrix from the dataframe of cleaned lyrics
  dtm <- TermDocumentMatrix(cleanedlyrics[, 1])
  matrix <- as.matrix(dtm)
  words <- sort(rowSums(matrix), decreasing = TRUE)
  df <- data.frame(word = names(words), freq = words)

  #making the actual wordcloud using the wordcloud package
  wordcloud(words = df$word, freq = df$freq, min.freq = 1, max.words = 500,
            random.order = FALSE, rot.per = 0.35, colors = brewer.pal(8, "Dark2") )
}


#' creates a bar plot of lyrics
#'
#' Creates a bar plot of the top 5 most used words in a Document Term Matrix or data frame of formatted and cleaned lyrics
#'
#' @importFrom tm TermDocumentMatrix
#'
#' @param cleanedlyrics data frame of formatted and cleaned lyrics by formatLyrics() and cleanLyrics() or a Document Term Matrix of lyrics
#' @param dtm boolean that indicates if cleanedlyrics is a data frame or Document Term Matrix
#'
#' @return bar plot of top five most used lyrics in data frame
#' @export
#'
#' @examples
#' billieLyrics <- getArtist('Billie Eilish')
#' formatted_lyrics <- formatLyrics(billieLyrics)
#' cleaned_lyrics <- cleanLyrics(formatted_lyrics, exp_contractions = TRUE)
#' my_dtm <- get_dtm(cleaned_lyrics)
#' top5words(cleaned_lyrics, dtm = F)
#' top5words(my_dtm, dtm = T)
top5words <- function(cleanedlyrics, dtm = FALSE) {
  #dtm or cleaned lyrics as input?
  if (dtm == TRUE) {
    #if input is already a DTM, do this
    bp <- barplot(cleanedlyrics$freq[1:5], names.arg = cleanedlyrics$word[1:5], col = "peachpuff4")
    return(invisible(bp))
  }

  #otherwise, we need to make a dtm first
  dtm <- TermDocumentMatrix(cleanedlyrics[, 1])
  matrix <- as.matrix(dtm)
  words <- sort(rowSums(matrix), decreasing = TRUE)
  df <- data.frame(word = names(words), freq = words)

  barplot(df$freq[1:5], names.arg = df$word[1:5], ylim = c(0,30),col = "peachpuff4")
}
