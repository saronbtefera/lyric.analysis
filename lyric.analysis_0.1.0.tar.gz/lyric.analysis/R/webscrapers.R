#' gets the lyrics from a song
#'
#' Retrieves the lyrics form a specific song from a specific artist from www.songlyrics.com
#'
#' @importFrom rvest html_elements html_text2 %>%
#' @importFrom xml2 read_html
#' @importFrom httr GET config
#'
#' @param name Name of the desired song
#' @param artist Name of the desired artist
#'
#' @return matrix/array of scraped lyrics
#' @export
#'
#' @examples
#' song <- getSong('Billie Eilish', 'Party Favor')
getSong <- function(name, artist){
  name <- tolower(gsub(" ","-", gsub("[().']","", gsub("'","-",name))))
  artist <- gsub(" ", "-", artist)
  url <- paste("https://www.songlyrics.com/",artist, "/", name, "-lyrics/", sep='')
  track_url <-url
  song <- track_url %>%
    httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>%
    read_html()
  songName <- song %>% html_elements("title") %>% html_text2()
  songlyrics <- song %>% html_elements('#songLyricsDiv') %>% html_text2()
  lyrics <- cbind(songlyrics, songName)
  lyrics
}


#' gets all an Artist's lyrics
#'
#' Retrieves all the lyrics from a specific artist from www.songlyrics.com
#'
#' @importFrom rvest html_nodes html_node html_attr html_elements html_text2 %>%
#' @importFrom xml2 read_html
#' @importFrom httr GET config
#'
#' @param artist Name of the desired artist
#'
#' @return matrix/array of scraped lyrics
#' @export
#'
#' @examples
#' billieLyrics <- getArtist("Billie Eilish")
getArtist <- function(artist){
  artist <- tolower(gsub(" ","-", gsub("[().]","", gsub("'","-",artist))))

  url <- paste('https://www.songlyrics.com/',artist,'-lyrics/', sep='')
  singer <- url %>%
    httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>%
    read_html()

  track_links <<- singer %>%
    html_nodes('table') %>% html_nodes('tr') %>% html_node('a') %>%
    html_attr('href')

  track_links <<- track_links[1:(length(track_links) - 2)]

  lyricVector <- c()
  songNameVector <- c()
  for(num in 1:length(track_links)){

    track_url <- track_links[num]
    song <- track_url %>%
      httr::GET(config = httr::config(ssl_verifypeer = TRUE)) %>%
      read_html()
    songName <- song %>% html_elements('title') %>% html_text2()
    lyrics <- song %>% html_elements('#songLyricsDiv') %>% html_text2()
    songNameVector[num] <- songName
    lyricVector[num] <- lyrics
  }
  lyrics <- cbind(lyricVector, songNameVector)
  lyrics
}
