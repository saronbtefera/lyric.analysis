#' Organizes scraped lyrics
#'
#' Formats the scraped lyrics into a data frame and removes HTML formatting characters
#'
#' @importFrom stringr str_split_fixed
#'
#' @param lyrics matrix/array of the scraped lyrics from getSong() or getArtist()
#'
#' @return data frame of formatted lyrics
#' @export
#'
#' @examples
#' billieLyrics <- getArtist('Billie Eilish')
#' formatted_lyrics <- formatLyrics(billieLyrics)
formatLyrics <- function(lyrics){
  list_mat <- list()
  for(num in 1:length(lyrics[,1])){
    a <- strsplit(lyrics[num,1], split = '\n')
    a <- unlist(a)

    z <- rep(lyrics[num,2], length(a))

    f <- cbind(a,z)

    list_mat[[num]] <- f

  }
  list_mat <- do.call(rbind, list_mat)
  list_mat <- data.frame(list_mat)

  list_mat[c('artist','song title')] <- str_split_fixed(list_mat$z, ' - ', 2)
  list_mat <- list_mat[c('a', 'artist', 'song title')]

  row.names(list_mat) <- NULL

  colnames(list_mat) <- c('lyrics', 'artist', 'song title')

  list_mat[,'lyrics'] <- sub('\r', "", list_mat[,'lyrics'])
  list_mat

}


#' cleans formatted lyrics
#'
#' Can expand contractions and removes punctuation from the scraped and formatted lyrics
#'
#' @importFrom textclean replace_number replace_contraction
#' @importFrom stringr str_replace_all
#'
#' @param lyr data frame of scraped lyrics from getSong() or getArtist() and formatted lyrics from formatLyrics()
#' @param expContractions boolean value that indicates if the user wants to expand the contractions
#'
#' @return data frame of cleaned lyrics
#' @export
#'
#' @examples
#' billieLyrics <- getArtist('Billie Eilish')
#' formatted_lyrics <- formatLyrics(billieLyrics)
#' cleaned_lyrics <- cleanLyrics(formatted_lyrics, exp_contractions = TRUE)
cleanLyrics <- function(lyr, expContractions = FALSE){
  lyr <- lyr[!(lyr$lyrics == ""), ] #get rid of empty lyric rows
  rownames(lyr) <- 1:nrow(lyr) # renumber index

  for(row in 1:length(lyr[,1])){ # converts digits to words
    lyr[row,1] <- replace_number(lyr[row,1])
  }

  if(expContractions == TRUE){
    for(row in 1:length(lyr[,1])){ # expands contractions
      lyr[row,1] <- replace_contraction(lyr[row,1])
    }
  }

  for(row in 1:length(lyr[,1])){
    lyr[row,1] <- str_replace_all(lyr[row,1], "[[:punct:]]", "")
  }

  lyr
}
