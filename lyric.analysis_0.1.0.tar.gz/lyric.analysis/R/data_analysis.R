#' Determines detected sentiments
#'
#' Calculates the percentages of detected sentiments in the lyrics
#'
#' @importFrom syuzhet get_nrc_sentiment
#'
#' @param x vector, or a column of a data frame, of lyrics
#'
#' @return NULL
#' @export
#'
#' @examples
#' billieLyrics <- getArtist('Billie Eilish')
#' formatted_lyrics <- formatLyrics(billieLyrics)
#' cleaned_lyrics <- cleanLyrics(formatted_lyrics, exp_contractions = TRUE)
#' sentimentProportion(cleaned_lyrics[,1])
sentimentProportion <- function(x){
  sentimentMatrix <- get_nrc_sentiment(x)
  proportions <- colSums(sentimentMatrix) / length(x)
  proportions
}


#' Produces a Document Term Matrix of lyrics
#'
#' Transforms the data frame of formatted and cleaned lyrics into a Document Term Matrix
#'
#' @importFrom tm TermDocumentMatrix
#'
#' @param cleanedlyrics data frame of formatted and cleaned lyrics by formatLyrics() and cleanLyrics()
#'
#' @return Document Term Matrix of lyrics
#' @export
#'
#' @examples
#' billieLyrics <- getArtist('Billie Eilish')
#' formatted_lyrics <- formatLyrics(billieLyrics)
#' cleaned_lyrics <- cleanLyrics(formatted_lyrics, exp_contractions = TRUE)
#' my_dtm <- get_dtm(cleaned_lyrics)
get_dtm <- function(cleanedlyrics){
  #making a document term matrix from the dataframe of cleaned lyrics
  dtm <- TermDocumentMatrix(cleanedlyrics[,1])
  matrix <- as.matrix(dtm)
  words <- sort(rowSums(matrix),decreasing=TRUE)
  df <- data.frame(word = names(words),freq=words)
}
